var mysql = require("mysql");
var config = require("./config");

var connection = mysql.createConnection(config.getConfig().db);

connection.connect();

function root(response, postData){
	// console.log("Request handler 'root' was called.");
	var sql = "INSERT INTO message (message) VALUES (?)";
	connection.query(sql, [postData], function(error, results, fields){
		
	});
	
	response.writeHead(200, {"Content-Type": "text/plain"});
	response.write('OK');
	response.end();	
}

function defaultHandler(response, postData){
	console.log("Request handler 'defaultHandler' was called.");
	response.writeHead(404, {"Content-Type": "text/plain"});
	response.write("404 Not found");
	response.end();	
}

exports.root = root;
exports.defaultHandler = defaultHandler;